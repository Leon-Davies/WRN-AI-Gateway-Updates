import { createSearchServer } from './search-server.mjs';
import { StdioServerTransport } from '@modelcontextprotocol/server/stdio';
import { searchConsensus } from './consensus-rest.mjs';

if (process.argv[2] === '--serve') {
  const server = createSearchServer(searchConsensus);
  await server.connect(new StdioServerTransport());
} else {
  process.stderr.write('Unsupported operation\n');
  process.exitCode = 2;
}
