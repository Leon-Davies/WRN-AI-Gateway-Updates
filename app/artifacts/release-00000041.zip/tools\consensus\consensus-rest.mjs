import { spawn } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const CONSENSUS_SEARCH_ENDPOINT = 'https://api.consensus.app/v1/search';
export const MAX_API_KEY_BYTES = 4096;
export const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;
export const REQUEST_TIMEOUT_MS = 15000;

const DEFAULT_VAULT = join(dirname(fileURLToPath(import.meta.url)), 'WRN-Consensus-Vault.exe');

export class ConsensusRestError extends Error {
  constructor(code) { super(code); this.name = 'ConsensusRestError'; this.code = code; }
}

function helperEnvironment(source = process.env) {
  const environment = {};
  for (const name of ['SystemRoot', 'WINDIR', 'PATH', 'TEMP', 'TMP', 'WRN_CONSENSUS_TEST_VAULT_ROOT']) {
    if (typeof source[name] === 'string' && source[name].length > 0) environment[name] = source[name];
  }
  return environment;
}

// The key is read only from the CurrentUser DPAPI helper's stdout pipe. It is
// never accepted from argv or an environment variable.
export function readRestApiKey({
  vaultPath = DEFAULT_VAULT,
  platform = process.platform,
  spawnChild = spawn,
  env = helperEnvironment(),
  timeoutMs = 5000,
} = {}) {
  if (platform !== 'win32') return Promise.reject(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
  return new Promise((resolveKey, rejectKey) => {
    let child;
    try {
      child = spawnChild(vaultPath, ['rest-read'], {
        stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true, env,
      });
    } catch {
      rejectKey(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
      return;
    }

    const chunks = [];
    let total = 0;
    let settled = false;
    const finish = (error, key) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) rejectKey(error); else resolveKey(key);
    };
    const timer = setTimeout(() => {
      try { child.kill(); } catch { /* contained */ }
      finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
    }, timeoutMs);
    child.stdout.on('data', chunk => {
      total += chunk.length;
      if (total > MAX_API_KEY_BYTES + 16) {
        try { child.kill(); } catch { /* contained */ }
        finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
        return;
      }
      chunks.push(Buffer.from(chunk));
    });
    child.once('error', () => finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE')));
    child.once('close', code => {
      if (settled) return;
      const bytes = Buffer.concat(chunks);
      if (code !== 0) return finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
      if (bytes.toString('ascii') === 'MISSING\n')
        return finish(new ConsensusRestError('CONSENSUS_KEY_MISSING'));
      if (bytes.length === 0 || bytes.length > MAX_API_KEY_BYTES)
        return finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
      let key;
      try { key = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
      catch { return finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE')); }
      if (!key || key.trim() !== key || /[\u0000-\u001f\u007f]/u.test(key))
        return finish(new ConsensusRestError('CONSENSUS_VAULT_UNAVAILABLE'));
      finish(null, key);
    });
  });
}

function firstText(record, names) {
  for (const name of names) {
    const value = record[name];
    if (typeof value === 'string' && value.trim()) return value.replace(/[\u0000-\u001f\u007f]/gu, ' ').trim().slice(0, 2000);
  }
  return '';
}

function normalizeYear(value) {
  if (Number.isInteger(value)) return value >= 1000 && value <= 2200 ? String(value) : '';
  if (typeof value === 'string') {
    const match = value.trim().match(/^(\d{4})(?:[-/].*)?$/u);
    return match && Number(match[1]) >= 1000 && Number(match[1]) <= 2200 ? match[1] : '';
  }
  return '';
}

function safeSourceUrl(value) {
  if (typeof value !== 'string' || !value.trim()) return '';
  try {
    const parsed = new URL(value.trim());
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password
        || parsed.href.length > 2048 || /[\u0000-\u0020\u007f]/u.test(value)) return '';
    return parsed.href;
  } catch { return ''; }
}

function authorsText(value) {
  if (typeof value === 'string') return value.trim().slice(0, 2000);
  if (!Array.isArray(value)) return '';
  return value.slice(0, 50).map(author => {
    if (typeof author === 'string') return author.trim();
    if (author && typeof author === 'object') return firstText(author, ['name', 'display_name']);
    return '';
  }).filter(Boolean).join(', ').slice(0, 2000);
}

function printable(value, max = 8000) {
  if (typeof value !== 'string') return '';
  return value.replace(/\r\n?/gu, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/gu, ' ').trim().slice(0, max);
}

function normalizePaper(paper) {
  if (!paper || typeof paper !== 'object' || Array.isArray(paper))
    throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID');
  const title = printable(paper.title, 2000).replace(/\n/gu, ' ');
  const year = normalizeYear(paper.publish_year ?? paper.year ?? paper.publication_year);
  const doi = firstText(paper, ['doi', 'DOI']).slice(0, 500);
  const url = safeSourceUrl(paper.url ?? paper.source_url ?? paper.paper_url ?? paper.canonical_url);
  if (!title || (!doi && !url)) throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID');

  const lines = [`${title}${year ? ` (${year})` : ''}`];
  const authors = authorsText(paper.authors ?? paper.author);
  const journal = firstText(paper, ['journal_name', 'journal', 'publication', 'source_name']);
  if (authors) lines.push(`Authors: ${authors}`);
  if (journal) lines.push(`Journal: ${journal.slice(0, 500)}`);
  if (doi && /^10\.\d{4,9}\/[^\s<>"']+$/iu.test(doi)) lines.push(`DOI: ${doi.slice(0, 500)}`);
  for (const [name, label] of [
    ['study_type', 'Study type'], ['sample_size', 'Sample size'],
    ['study_count', 'Study count'], ['citation_count', 'Citations'],
    ['sjr_best_quartile', 'SJR quartile'], ['population_type', 'Population'],
    ['preprint_status', 'Preprint status'],
  ]) {
    const value = paper[name];
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean')
      lines.push(`${label}: ${String(value).slice(0, 300)}`);
  }
  const takeaway = printable(paper.takeaway, 2000);
  const abstract = printable(paper.abstract, 8000);
  if (takeaway) lines.push(`Takeaway: ${takeaway}`);
  if (abstract) lines.push(`Abstract: ${abstract}`);
  if (url) lines.push(`Source: ${url}`);
  return lines.join('\n');
}

export function parseSearchResponse(value, pageSize = 10) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || !Array.isArray(value.results))
    throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID');
  if (value.results.length === 0) return 'No papers were returned for this search.';
  return value.results.slice(0, pageSize).map(normalizePaper).join('\n\n');
}

async function boundedBody(response, maxBytes, signal) {
  if (!response.body) throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID');
  const reader = response.body.getReader();
  const cancelOnAbort = () => { reader.cancel().catch(() => {}); };
  signal?.addEventListener('abort', cancelOnAbort, { once: true });
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel().catch(() => {});
        throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID');
      }
      chunks.push(Buffer.from(value));
    }
  } finally { signal?.removeEventListener('abort', cancelOnAbort); reader.releaseLock(); }
  try { return new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks)); }
  catch { throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID'); }
}

function statusError(status) {
  if (status === 401 || status === 403) return 'CONSENSUS_AUTH_INVALID';
  if (status === 429) return 'CONSENSUS_QUOTA_REACHED';
  if (status === 402) return 'CONSENSUS_ACCOUNT_BILLING';
  if (status >= 500 && status <= 599) return 'CONSENSUS_SERVICE_UNAVAILABLE';
  return 'CONSENSUS_SEARCH_FAILED';
}

export async function searchConsensus(args, {
  loadApiKey = readRestApiKey,
  fetchImpl = globalThis.fetch,
  timeoutMs = REQUEST_TIMEOUT_MS,
  maxResponseBytes = MAX_RESPONSE_BYTES,
} = {}) {
  if (typeof fetchImpl !== 'function') throw new ConsensusRestError('CONSENSUS_NETWORK_UNAVAILABLE');
  const key = await loadApiKey();
  const url = new URL(CONSENSUS_SEARCH_ENDPOINT);
  if (url.protocol !== 'https:' || url.hostname !== 'api.consensus.app' || url.pathname !== '/v1/search')
    throw new ConsensusRestError('CONSENSUS_ENDPOINT_REJECTED');
  url.searchParams.set('query', args.query);
  url.searchParams.set('page_size', String(args.page_size ?? 10));

  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
  let response;
  try {
    response = await fetchImpl(url, {
      method: 'GET',
      headers: { Accept: 'application/json', 'x-api-key': key },
      redirect: 'manual',
      signal: controller.signal,
    });
    if (response.url) {
      let finalUrl;
      try { finalUrl = new URL(response.url); }
      catch { throw new ConsensusRestError('CONSENSUS_REDIRECT_REJECTED'); }
      if (finalUrl.href !== url.href) throw new ConsensusRestError('CONSENSUS_REDIRECT_REJECTED');
    }
    if (response.status >= 300 && response.status < 400)
      throw new ConsensusRestError('CONSENSUS_REDIRECT_REJECTED');
    if (response.status < 200 || response.status >= 300)
      throw new ConsensusRestError(statusError(response.status));
    const text = await boundedBody(response, maxResponseBytes, controller.signal);
    if (timedOut) throw new ConsensusRestError('CONSENSUS_TIMEOUT');
    let payload;
    try { payload = JSON.parse(text); }
    catch { throw new ConsensusRestError('CONSENSUS_RESPONSE_INVALID'); }
    return { content: [{ type: 'text', text: parseSearchResponse(payload, args.page_size ?? 10) }] };
  } catch (error) {
    try { response?.body?.cancel()?.catch(() => {}); } catch { /* contained */ }
    if (error instanceof ConsensusRestError) throw error;
    throw new ConsensusRestError(timedOut ? 'CONSENSUS_TIMEOUT' : 'CONSENSUS_NETWORK_UNAVAILABLE');
  } finally { clearTimeout(timer); }
}

export function safeSearchError(error) {
  const code = error instanceof ConsensusRestError ? error.code : 'CONSENSUS_SEARCH_FAILED';
  const messages = {
    CONSENSUS_KEY_MISSING: 'No Consensus API key is saved. Paste your key and choose Connect.',
    CONSENSUS_VAULT_UNAVAILABLE: 'The saved Consensus key could not be read. Reset or replace it in Gateway settings.',
    CONSENSUS_AUTH_INVALID: 'Consensus rejected this API key. Check or replace it in the API & MCP dashboard.',
    CONSENSUS_QUOTA_REACHED: 'Consensus reports a usage limit or request rate limit. Check API & MCP usage and retry later.',
    CONSENSUS_ACCOUNT_BILLING: 'Consensus has paused API access for this account. Check its billing status.',
    CONSENSUS_NETWORK_UNAVAILABLE: 'Consensus could not be reached. Check your connection and retry.',
    CONSENSUS_SERVICE_UNAVAILABLE: 'Consensus is temporarily unavailable. Try again later.',
    CONSENSUS_TIMEOUT: 'Consensus search timed out. Try again.',
    CONSENSUS_RESPONSE_INVALID: 'Consensus returned an unexpected search response. Try again later.',
    CONSENSUS_REDIRECT_REJECTED: 'Consensus returned an unexpected redirect. The request was stopped for safety.',
    CONSENSUS_ENDPOINT_REJECTED: 'Consensus search could not be started safely.',
    CONSENSUS_SEARCH_FAILED: 'Consensus search failed. Check the API key or try again later.',
  };
  return { code, message: messages[code] ?? messages.CONSENSUS_SEARCH_FAILED };
}
