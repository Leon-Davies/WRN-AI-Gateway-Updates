// One real official REST search through the exact local MCP surface.
import { Client } from '@modelcontextprotocol/client';
import { StdioClientTransport } from '@modelcontextprotocol/client/stdio';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=dirname(fileURLToPath(import.meta.url));
const transport = new StdioClientTransport({
  command:process.execPath,
  args:[join(root,'bridge.mjs'),'--serve'],
  env:process.env,
  stderr:'pipe'
});
const client=new Client({name:'WRN-AI-Gateway-Consensus-Test',version:'1.0'});
try {
  await client.connect(transport);
  const tools=(await client.listTools()).tools.map(t=>t.name);
  if(tools.length!==1||tools[0]!=='search')throw new Error('UNAPPROVED_TOOLS');
  let rejected=false;
  try { await client.callTool({ name:'create_thread', arguments:{} }); } catch { rejected=true; }
  if (!rejected) throw new Error('FORBIDDEN_CALL_EXPOSED');
  const result=await client.callTool({name:'search',arguments:{
    query:'systematic review exercise cognitive function older adults',page_size:1
  }},undefined,{timeout:45000});
  if (result?.isError) {
    const message = Array.isArray(result.content)
      ? result.content.filter(t=>t.type==='text').map(t=>t.text||'').join(' ') : '';
    for (const [pattern, marker] of [
      [/CONSENSUS_QUOTA_REACHED|CONSENSUS_ACCOUNT_BILLING/, 'CONSENSUS_SEARCH_LIMIT_REACHED'],
      [/CONSENSUS_AUTH_INVALID/, 'CONSENSUS_AUTH_INVALID'],
      [/CONSENSUS_KEY_MISSING/, 'CONSENSUS_KEY_MISSING'],
      [/CONSENSUS_TIMEOUT/, 'CONSENSUS_TIMEOUT'],
      [/CONSENSUS_SERVICE_UNAVAILABLE/, 'CONSENSUS_SERVICE_UNAVAILABLE'],
      [/CONSENSUS_NETWORK_UNAVAILABLE/, 'CONSENSUS_NETWORK_UNAVAILABLE'],
      [/CONSENSUS_RESPONSE_INVALID/, 'CONSENSUS_RESPONSE_INVALID'],
    ]) if (pattern.test(message)) throw new Error(marker);
    throw new Error('SEARCH_FAILED');
  }
  if (!Array.isArray(result?.content)) throw new Error('SEARCH_FAILED');
  const content=result.content.filter(t=>t.type==='text').map(t=>t.text||'').join('\n');
  if(!/Source: https?:\/\//.test(content))
    throw new Error('SOURCES_MISSING');
  process.stdout.write('CONSENSUS_SEARCH_TESTED\n');
}catch(error){
  process.stdout.write(['CONSENSUS_SEARCH_LIMIT_REACHED','CONSENSUS_AUTH_INVALID','CONSENSUS_KEY_MISSING','CONSENSUS_TIMEOUT','CONSENSUS_SERVICE_UNAVAILABLE','CONSENSUS_NETWORK_UNAVAILABLE','CONSENSUS_RESPONSE_INVALID'].includes(error?.message)
    ? `${error.message}\n` : 'CONSENSUS_SEARCH_UNAVAILABLE\n');
  process.exitCode=2;
}finally{
  await client.close().catch(()=>{});await transport.close().catch(()=>{});
}
