// Restrictive RMS IRP local MCP adapter; no model jobs or arbitrary API execution.
import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Client, StreamableHTTPClientTransport } from '@modelcontextprotocol/client';
import { Server } from '@modelcontextprotocol/server';
import { StdioServerTransport } from '@modelcontextprotocol/server/stdio';
const root=dirname(fileURLToPath(import.meta.url));
const ENDPOINTS=Object.freeze({EU:'https://api-euw1.rms.com/platform/integration/v1/mcp',US:'https://api-use1.rms.com/platform/integration/v1/mcp'});
export const APPROVED=Object.freeze(['graph-suggest-workflow','graph-find-related','graph-explore','graph-get-workflow','graph-validate-chain','get-doc-context','vector-search','search-api-spec','get-operation-spec','search-workflows','get-workflow','get-operation-sample']);
export const permitted=(name)=>typeof name==='string'&&APPROVED.includes(name);
const CLEAN_ERROR=Object.freeze({AUTH:'RMS_AUTH_INVALID: Check the region and the individual IRP API key.',ENTITLEMENT:'RMS_ENTITLEMENT_REQUIRED: The tenant/key needs IRP Agentic Tools User and MCP server access.',TIMEOUT:'RMS_TIMEOUT: IRP did not respond within the request limit.',SERVICE:'RMS_SERVICE_UNAVAILABLE: The RMS IRP service cannot be reached.',INVALID:'RMS_RESPONSE_INVALID: The upstream MCP response was invalid.',BLOCKED:'RMS_TOOL_BLOCKED: Only documented read-only discovery tools are available.'});
function fail(code){throw new Error(CLEAN_ERROR[code]||CLEAN_ERROR.INVALID);}
export function validateTools(result){
 if(!result||!Array.isArray(result.tools))fail('INVALID');
 const seen=new Set();
 return result.tools.filter(t=>{
   if(!t||typeof t.name!=='string'||typeof t.inputSchema!=='object'||t.inputSchema===null)return false;
   if(!permitted(t.name)||seen.has(t.name))return false;
   seen.add(t.name);return true;
 });
}
function limited(text,max=1048576){if(typeof text!=='string'||Buffer.byteLength(text)>max)fail('INVALID');return text;}
async function keyFromVault(){
 const vault=join(root,'WRN-RMS-Vault.exe');
 return await new Promise((resolve,reject)=>{
  const child=spawn(vault,['read'],{stdio:['ignore','pipe','ignore'],windowsHide:true});
  let b=Buffer.alloc(0);
  child.stdout.on('data',x=>{b=Buffer.concat([b,x]);if(b.length>4096){child.kill();reject(new Error(CLEAN_ERROR.AUTH));}});
  const timer=setTimeout(()=>{child.kill();reject(new Error(CLEAN_ERROR.TIMEOUT));},8000);
  child.on('error',()=>{clearTimeout(timer);reject(new Error(CLEAN_ERROR.AUTH));});
  child.on('close',code=>{clearTimeout(timer);if(code!==0||b.toString('utf8')==='MISSING'||b.length<1||b.length>4096)return reject(new Error(CLEAN_ERROR.AUTH));resolve(b.toString('utf8'));b.fill(0);});
 });
}
export async function openRms({region,key,fetchImpl=fetch,remoteClientFactory=null}={}) {
 if(!Object.hasOwn(ENDPOINTS,region))fail('INVALID');
 if(typeof key!=='string'||key.length<1||key.length>4096)fail('AUTH');
 const endpoint=ENDPOINTS[region];
 const approvedUrl=new URL(endpoint);
 async function protectedFetch(input,opts={}){
   const u=new URL(typeof input==='string'||input instanceof URL?input:input.url);
   if(u.href!==approvedUrl.href)fail('BLOCKED');
   const h=new Headers(opts.headers||input?.headers);
   h.set('Authorization',key);  // Vendor documents raw key, without Bearer prefix.
   const signal=opts.signal?AbortSignal.any([opts.signal,AbortSignal.timeout(18000)]):AbortSignal.timeout(18000);
   let r;
   try {r=await fetchImpl(input,{...opts,headers:h,redirect:'manual',signal});}
   catch(e){if(e?.name==='TimeoutError'||e?.name==='AbortError')fail('TIMEOUT');fail('SERVICE');}
   if(r.status===401)fail('AUTH');if(r.status===403)fail('ENTITLEMENT');
   if(r.status===429||r.status>=500)fail('SERVICE');
   if(r.status>=300&&r.status<400)fail('BLOCKED');
   if(!r.ok)fail('INVALID');
   if(r.url && r.url!==u.href)fail('BLOCKED');
   return r;
 }
 const client=remoteClientFactory?await remoteClientFactory(protectedFetch):new Client({name:'wrn-rms-readonly',version:'1.0.0'});
 const transport=remoteClientFactory?null:new StreamableHTTPClientTransport(new URL(endpoint),{fetch:protectedFetch});
 try {if(transport)await client.connect(transport);}catch(e){try{await client.close();}catch{};if(e?.message?.startsWith('RMS_'))throw e;fail('SERVICE');}
 async function catalogue(){try{return validateTools(await client.listTools());}catch(e){if(e?.message?.startsWith('RMS_'))throw e;fail('SERVICE');}}
 async function invoke(name,args){
  if(!permitted(name))fail('BLOCKED');
  if(!args||typeof args!=='object'||Array.isArray(args))fail('INVALID');
  if(Buffer.byteLength(JSON.stringify(args))>65536)fail('INVALID');
  // Vendor-defined tool schema remains the source of truth; never use an undocumented tool.
  const tools=await catalogue(); if(!tools.some(t=>t.name===name))fail('BLOCKED');
  try {
    const data=await client.callTool({name,arguments:args});
    if(!data||!Array.isArray(data.content))fail('INVALID');
    const body=limited(JSON.stringify(data));
    if(body.includes(key))fail('INVALID');
    return JSON.parse(body);
  }catch(e){if(e?.message?.startsWith('RMS_'))throw e;fail('SERVICE');}
 }
 return {catalogue,invoke,close:async()=>client.close()};
}
export async function runBridge({mode=process.argv[2], regionOverride=null, keyOverride=null, fetchImpl=fetch, remoteClientFactory=null}={}){
 const region=regionOverride||String(await readFile(join(root,'region.txt'),'utf8')).trim();
 const key=keyOverride||await keyFromVault();
 const remote=await openRms({region,key,fetchImpl,remoteClientFactory});
 try{
  const tools=await remote.catalogue();
  if(!tools.length)fail('ENTITLEMENT');
  if(mode==='--probe') {process.stdout.write('RMS_READONLY_DISCOVERY_TESTED');return;}
  if(mode!=='--serve')fail('BLOCKED');
  // Low-level official SDK server preserves upstream JSON schemas verbatim.
  const server=new Server({name:'wrn-rms-readonly',version:'1.0.0'},{capabilities:{tools:{}}});
  server.setRequestHandler('tools/list',async()=>({tools:tools.map(t=>({name:t.name,description:t.description||'',inputSchema:t.inputSchema}))}));
  server.setRequestHandler('tools/call',async request=>{
    const {name,arguments:args={}}=request.params;
    if(!permitted(name))return {isError:true,content:[{type:'text',text:CLEAN_ERROR.BLOCKED}]};
    try{return await remote.invoke(name,args);}catch{return {isError:true,content:[{type:'text',text:CLEAN_ERROR.SERVICE}]};}
  });
  await server.connect(new StdioServerTransport());
 }finally{if(mode==='--probe')await remote.close();}
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===process.argv[1]){
 runBridge().catch(e=>{if(process.argv[2]==='--probe'){process.stdout.write((e?.message||'').startsWith('RMS_')?e.message.split(':')[0]:'RMS_SERVICE_UNAVAILABLE');}else{process.stderr.write('RMS_CONNECTION_FAILED\n');}process.exitCode=2;});
}
