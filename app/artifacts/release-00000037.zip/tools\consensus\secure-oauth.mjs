import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

export const ENDPOINT = 'https://mcp.consensus.app/mcp';
export const ISSUER = 'https://consensus.app';
const MAX_VAULT_OUTPUT = 262144;

// Windows-only executable: CurrentUser DPAPI. Never silently store tokens on Linux.
export class WindowsDpapiVault {
  constructor(exe = join(dirname(fileURLToPath(import.meta.url)), 'WRN-Consensus-Vault.exe')) {
    if (process.platform !== 'win32') throw new Error('CONSENSUS_WINDOWS_VAULT_REQUIRED');
    this.exe = exe;
  }
  async operation(name, value) {
    if (!['read', 'write', 'delete'].includes(name)) throw new Error('CONSENSUS_VAULT_OPERATION_INVALID');
    const result = await new Promise((resolve, reject) => {
      const p = spawn(this.exe, [name], { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] });
      let out = ''; let exceeded = false;
      const timeout = setTimeout(() => { p.kill(); reject(new Error('CONSENSUS_VAULT_TIMEOUT')); }, 10000);
      p.on('error', err => { clearTimeout(timeout); reject(new Error('CONSENSUS_VAULT_UNAVAILABLE', { cause: err })); });
      p.stdout.on('data', chunk => { out += chunk.toString('utf8'); if (out.length > MAX_VAULT_OUTPUT) { exceeded = true; p.kill(); } });
      p.on('close', code => { clearTimeout(timeout); if (exceeded || code !== 0) reject(new Error('CONSENSUS_VAULT_FAILURE')); else resolve(out.trim()); });
      p.stdin.on('error', () => {});
      p.stdin.end(value === undefined ? '' : Buffer.from(JSON.stringify(value), 'utf8').toString('base64') + '\n');
    });
    return result;
  }
  async read() {
    const encoded = await this.operation('read');
    if (encoded === 'MISSING') return undefined;
    try { return JSON.parse(Buffer.from(encoded, 'base64').toString('utf8')); }
    catch { throw new Error('CONSENSUS_VAULT_CORRUPT'); }
  }
  async write(data) { if (await this.operation('write', data) !== 'OK') throw new Error('CONSENSUS_VAULT_FAILURE'); }
  async delete() { if (await this.operation('delete') !== 'OK') throw new Error('CONSENSUS_VAULT_FAILURE'); }
}

export function pinnedFetch(input, init) {
  const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
  const permitted = (url.origin === 'https://mcp.consensus.app' &&
    (url.pathname === '/mcp' || url.pathname.startsWith('/.well-known/oauth-protected-resource'))) ||
    (url.origin === ISSUER &&
      (url.pathname.startsWith('/.well-known/oauth-authorization-server') ||
       url.pathname === '/oauth/register/' || url.pathname === '/oauth/token/' ||
       url.pathname === '/oauth/revoke/'));
  if (!permitted || url.username || url.password || url.hash)
    throw new Error('CONSENSUS_ENDPOINT_REJECTED');
  // Never permit a redirect to a different host or endpoint (including OAuth discovery).
  // Preserve Request method, headers and body when the SDK passes a Request object.
  const request = input instanceof Request ? input : url;
  return fetch(request, { ...init, redirect: 'manual' }).then(response => {
    if (response.status >= 300 && response.status < 400)
      throw new Error('CONSENSUS_REDIRECT_REJECTED');
    return response;
  });
}

export class ConsensusOAuthProvider {
  constructor(vault, redirectCallback = async () => { throw new Error('CONSENSUS_AUTH_REQUIRED'); }) {
    this.vault = vault;
    this.redirectCallback = redirectCallback;
    this.cached = undefined;
    this.verifier = undefined;
    this.authState = undefined;
  }
  get redirectUrl() { return new URL('http://127.0.0.1:6761/callback'); }
  get clientMetadata() {
    return {
      client_name: 'WRN AI Gateway - Consensus academic search',
      redirect_uris: [this.redirectUrl.toString()],
      grant_types: ['authorization_code', 'refresh_token'],
      response_types: ['code'],
      token_endpoint_auth_method: 'none',
      scope: 'search'
    };
  }
  async state() { this.authState = randomUUID(); return this.authState; }
  async load() {
    if (this.cached === undefined) {
      const record = await this.vault.read();
      if (!record) this.cached = { endpoint: ENDPOINT, issuer: ISSUER, tokens: null, client: null };
      else if (record.endpoint !== ENDPOINT || record.issuer !== ISSUER || record.version !== 1)
        throw new Error('CONSENSUS_CREDENTIAL_BINDING_INVALID');
      else this.cached = record;
    }
    return this.cached;
  }
  async persist() { const record = await this.load(); await this.vault.write({ ...record, version: 1 }); }
  checkIssuer(ctx) {
    if (ctx?.issuer && ctx.issuer !== ISSUER) throw new Error('CONSENSUS_ISSUER_REJECTED');
  }
  async clientInformation(ctx) { this.checkIssuer(ctx); return (await this.load()).client ?? undefined; }
  async saveClientInformation(client, ctx) {
    this.checkIssuer(ctx); (await this.load()).client = { ...client, issuer: ISSUER }; await this.persist();
  }
  async tokens(ctx) { this.checkIssuer(ctx); return (await this.load()).tokens ?? undefined; }
  async saveTokens(tokens, ctx) {
    this.checkIssuer(ctx); (await this.load()).tokens = { ...tokens, issuer: ISSUER }; await this.persist();
  }
  async invalidateCredentials(scope) {
    const record = await this.load();
    if (scope === 'all' || scope === 'client') record.client = null;
    if (scope === 'all' || scope === 'tokens') record.tokens = null;
    if (scope === 'all' || scope === 'verifier') this.verifier = undefined;
    await this.persist();
  }
  async saveCodeVerifier(verifier) { this.verifier = verifier; }
  async codeVerifier() { if (!this.verifier) throw new Error('CONSENSUS_OAUTH_VERIFIER_MISSING'); return this.verifier; }
  async redirectToAuthorization(url) {
    const target = new URL(url);
    if (target.origin !== ISSUER || target.pathname !== '/oauth/authorize/' ||
        target.username || target.password || target.hash)
      throw new Error('CONSENSUS_AUTHORIZATION_URL_REJECTED');
    await this.redirectCallback(target, this.authState);
  }
}
