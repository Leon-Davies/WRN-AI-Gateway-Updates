import { Server } from '@modelcontextprotocol/server';
import { StdioServerTransport } from '@modelcontextprotocol/server/stdio';
import { safeSearchError } from './consensus-rest.mjs';

export const SEARCH_TOOL = Object.freeze({
  name: 'search',
  description: 'Search scholarly research using Consensus. Queries are sent to the external Consensus service; use only public academic questions.',
  inputSchema: { type: 'object', properties: {
    query: { type: 'string', minLength: 3, maxLength: 1000, description: 'Public academic research query' },
    page_size: { type: 'integer', minimum: 1, maximum: 20, description: 'Maximum results requested' }
  }, required: ['query'], additionalProperties: false }
});

export function validateSearch(name, args) {
  if (name !== 'search') throw new Error('CONSENSUS_FORBIDDEN_TOOL');
  if (!args || Array.isArray(args) || typeof args !== 'object') throw new Error('CONSENSUS_INVALID_ARGUMENTS');
  if (Object.keys(args).some(k => !['query', 'page_size'].includes(k))) throw new Error('CONSENSUS_INVALID_ARGUMENTS');
  if (typeof args.query !== 'string' || args.query.trim().length < 3 || args.query.length > 1000)
    throw new Error('CONSENSUS_INVALID_ARGUMENTS');
  if (args.page_size !== undefined && (!Number.isInteger(args.page_size) || args.page_size < 1 || args.page_size > 20))
    throw new Error('CONSENSUS_INVALID_ARGUMENTS');
  return { query: args.query.trim(), ...(args.page_size ? { page_size: args.page_size } : {}) };
}

export function createSearchServer(forwardSearch) {
  const server = new Server({ name: 'wrn-consensus-search', version: '0.1.0' }, { capabilities: { tools: {} } });
  server.setRequestHandler('tools/list', async () => ({ tools: [SEARCH_TOOL] }));
  server.setRequestHandler('tools/call', async request => {
    // Reject the operation before invoking any remote client.
    const args = validateSearch(request.params?.name, request.params?.arguments);
    try {
      const result = await forwardSearch(args);
      if (!result || !Array.isArray(result.content)) throw new Error('CONSENSUS_RESPONSE_INVALID');
      return result; // Original academic metadata and URLs pass through without summarisation.
    } catch (error) {
      const safe = safeSearchError(error);
      return { isError: true, content: [{ type: 'text', text: `${safe.code}: ${safe.message}` }] };
    }
  });
  return server;
}
export async function serve(forwardSearch) {
  const server = createSearchServer(forwardSearch);
  await server.connect(new StdioServerTransport());
  return server;
}
